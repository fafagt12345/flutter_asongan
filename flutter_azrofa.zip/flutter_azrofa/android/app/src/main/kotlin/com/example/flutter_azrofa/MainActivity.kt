package com.example.flutter_azrofa

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
