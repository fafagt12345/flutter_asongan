class DetailPage extends StatelessWidget {
  final String username;
  final String email;
  const DetailPage({super.key, required this.username, required this.email});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail User'),
        backgroundColor: const Color(0xFF1976D2),
      ),
      backgroundColor: const Color(0xFFE3F2FD),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.person, size: 80, color: Color(0xFF1976D2)),
            const SizedBox(height: 24),
            Text('Username:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text(username, style: const TextStyle(fontSize: 20)),
            const SizedBox(height: 16),
            Text('Email:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text(email, style: const TextStyle(fontSize: 20)),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Penjualan Barang & Minuman',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {

  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  String? _error;

  // Simpan akun baru di memory (dummy, tidak persistent)
  final Map<String, String> _users = {'admin': '1234'};
  final Map<String, String> _emails = {'admin': 'admin@admin.com'};
  String? _currentUser;

  void _login() {
    final username = _usernameController.text;
    final password = _passwordController.text;
    if (_users.containsKey(username) && _users[username] == password) {
      setState(() {
        _currentUser = username;
      });
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => HomePage(
            username: username,
            email: _emails[username] ?? '-',
          ),
        ),
      );
    } else {
      setState(() {
        _error = 'Username atau password salah';
      });
    }
  }

  void _register() {
    final username = _usernameController.text;
    final password = _passwordController.text;
    final email = _emailController.text;
    if (username.isEmpty || password.isEmpty || email.isEmpty) {
      setState(() {
        _error = 'Username, password, dan email harus diisi';
      });
      return;
    }
    if (_users.containsKey(username)) {
      setState(() {
        _error = 'Username sudah terdaftar';
      });
      return;
    }
    setState(() {
      _users[username] = password;
      _emails[username] = email;
      _error = 'Akun berhasil dibuat! Silakan login.';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login'),
        backgroundColor: const Color(0xFF1976D2),
      ),
      backgroundColor: const Color(0xFFE3F2FD),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'assets/images/logo gagak.png',
              width: 100,
              height: 100,
              errorBuilder: (context, error, stackTrace) => const Icon(Icons.image_not_supported, size: 100, color: Colors.grey),
            ),
            const SizedBox(height: 24),
            TextField(
              controller: _usernameController,
              decoration: const InputDecoration(
                labelText: 'Username',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(
                labelText: 'Email',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _passwordController,
              decoration: const InputDecoration(
                labelText: 'Password',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(),
              ),
              obscureText: true,
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF1976D2),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    onPressed: _login,
                    child: const Text('Login', style: TextStyle(fontSize: 18)),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    onPressed: _register,
                    child: const Text('Buat Akun', style: TextStyle(fontSize: 18)),
                  ),
                ),
              ],
            ),
            if (_error != null) ...[
              const SizedBox(height: 16),
              Text(_error!, style: const TextStyle(color: Colors.red)),
            ],
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final String username;
  final String email;
  const HomePage({super.key, required this.username, required this.email});

  final List<Map<String, dynamic>> items = const [
    {'name': 'Air Mineral', 'price': 5000},
    {'name': 'Teh Botol', 'price': 7000},
    {'name': 'Kopi', 'price': 10000},
    {'name': 'Roti', 'price': 8000},
    {'name': 'Snack', 'price': 6000},
    {'name': 'Susu', 'price': 9000},
    {'name': 'Coklat', 'price': 12000},
    {'name': 'Keripik', 'price': 7000},
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          color: const Color(0xFF1976D2),
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Selamat datang, $username!', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text('Email: $email', style: const TextStyle(color: Colors.white, fontSize: 16)),
            ],
          ),
        ),
        Expanded(child: _HomePageCheckout(items: items)),
      ],
    );
  }
}

class _HomePageCheckout extends StatefulWidget {
  final List<Map<String, dynamic>> items;
  const _HomePageCheckout({required this.items});

  @override
  State<_HomePageCheckout> createState() => _HomePageCheckoutState();
}

class _HomePageCheckoutState extends State<_HomePageCheckout> {
  late List<bool> _selected;

  @override
  void initState() {
    super.initState();
    _selected = List<bool>.filled(widget.items.length, false);
  }

  void _checkout() {
    final selectedItems = <Map<String, dynamic>>[];
    int total = 0;
    for (int i = 0; i < widget.items.length; i++) {
      if (_selected[i]) {
        selectedItems.add(widget.items[i]);
        total += widget.items[i]['price'] as int;
      }
    }
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Checkout'),
        content: selectedItems.isEmpty
            ? const Text('Tidak ada barang yang dipilih.')
            : Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ...selectedItems.map((item) => Text('- ${item['name']} (Rp ${item['price']})')),
                  const SizedBox(height: 12),
                  Text('Total: Rp $total', style: const TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Barang & Minuman'),
        backgroundColor: const Color(0xFF1565C0),
      ),
      backgroundColor: const Color(0xFFBBDEFB),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: widget.items.length,
              itemBuilder: (context, index) {
                final item = widget.items[index];
                return Card(
                  color: Colors.white,
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: CheckboxListTile(
                    title: Text(item['name'], style: const TextStyle(color: Color(0xFF1565C0), fontWeight: FontWeight.bold)),
                    subtitle: Text('Rp ${item['price']}', style: const TextStyle(color: Color(0xFF1976D2))),
                    value: _selected[index],
                    activeColor: const Color(0xFF1976D2),
                    onChanged: (val) {
                      setState(() {
                        _selected[index] = val ?? false;
                      });
                    },
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1976D2),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                icon: const Icon(Icons.shopping_cart_checkout),
                label: const Text('Checkout', style: TextStyle(fontSize: 18)),
                onPressed: _checkout,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
