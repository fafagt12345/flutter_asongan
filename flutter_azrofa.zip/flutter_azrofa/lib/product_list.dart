import 'package:flutter/material.dart';



// Base class untuk Mainan
abstract class MainanBase {
  String get nama;
  String get nomor;
  double get harga;
}

class Mainan extends MainanBase {
  String _nama;
  String _nomor;
  double _harga;

  Mainan(this._nama, this._nomor, this._harga);

  @override
  String get nama => _nama;
  @override
  String get nomor => _nomor;
  @override
  double get harga => _harga;

  set nama(String value) => _nama = value;
  set nomor(String value) => _nomor = value;
  set harga(double value) => _harga = value;

  @override
  String toString() {
    return 'Mainan: $nama, Nomor: $nomor, Harga: Rp${harga.toStringAsFixed(0)}';
  }
}

final mainan1 = Mainan('Mobil Remote', '001', 150000.0);
final mainan2 = Mainan('Boneka Beruang', '002', 85000.0);
final mainan3 = Mainan('Puzzle Kayu', '003', 45000.0);
final mainan4 = Mainan('Robot Pintar', '004', 220000.0);
final mainan5 = Mainan('Lego Classic', '005', 175000.0);

final List<Mainan> daftarMainan = [
  mainan1,
  mainan2,
  mainan3,
  mainan4,
  mainan5,
];
