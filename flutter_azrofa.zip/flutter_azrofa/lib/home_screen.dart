import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  final List<Map<String, dynamic>> items = const [
    {'name': 'Air Mineral', 'price': 5000},
    {'name': 'Teh Botol', 'price': 7000},
    {'name': 'Kopi', 'price': 10000},
    {'name': 'Roti', 'price': 8000},
    {'name': 'Snack', 'price': 6000},
    {'name': 'Susu', 'price': 9000},
    {'name': 'Coklat', 'price': 12000},
    {'name': 'Keripik', 'price': 7000},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Daftar Barang & Minuman')),
      body: ListView.builder(
        itemCount: items.length,
        itemBuilder: (context, index) {
          final item = items[index];
          return ListTile(
            title: Text(item['name']),
            trailing: Text('Rp ${item['price']}'),
          );
        },
      ),
    );
  }
}
