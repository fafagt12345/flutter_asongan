import 'package:flutter/material.dart';

enum AuthState {
  unknown,
  authenticated,
  unauthenticated,
}

class AuthStateProvider extends ChangeNotifier {
  AuthState _state = AuthState.unknown;

  AuthState get state => _state;

  void login(String username, String password) {
    if (username == 'admin' && password == '1234') {
      _state = AuthState.authenticated;
    } else {
      _state = AuthState.unauthenticated;
    }
    notifyListeners();
  }

  void logout() {
    _state = AuthState.unauthenticated;
    notifyListeners();
  }
}
